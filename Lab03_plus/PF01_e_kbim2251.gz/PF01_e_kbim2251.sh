#!/bin/bash

#Korpos Botond
#kbim2251
#522/2

if [ -e tmp-ritmus ]
then
	rm tmp-ritmus
fi

if [[ $1 -gt 4 ]] && [[ $1 -lt 11 ]]
then
	touch tmp-ritmus
	itr=$1
	while [[ $itr -ge 0 ]]
	do
		i=16
		while [[ $i -gt 0 ]]
		do
			nanosec=$(date +%N)
			nanoseco=$((nanosec % 10))
			if [[ $nanoseco -eq 0 ]] || [[ $nanoseco -eq 1 ]] || [[ $nanoseco -eq 2 ]] || [[ $nanoseco -eq 3 ]]
			then
				echo -n ". " >> tmp-ritmus
				((i--))
			fi
			if [[ $nanoseco -eq 4 ]] || [[ $nanoseco -eq 5 ]] || [[ $nanoseco -eq 6 ]] || [[ $nanoseco -eq 7 ]]
			then
				echo -n "| " >> tmp-ritmus
				((i = i - 2))
			else
				echo -n "s " >> tmp-ritmus
				((i = i - 2))
			fi
			if [[ $i -eq 0 ]]
			then
				echo "" >> tmp-ritmus
				((i=0))
			fi
			if [[ $i -eq 1 ]]
			then
				echo -n ". " >> tmp-ritmus
				echo "" >> tmp-ritmus
				((i=0))
			fi
		done
		((itr--))
	done	
fi

if [[ -f $1 && $(file -b $1) =~ "text" ]] || [ -e tmp-ritmus ]
then    
	file=$1
	if [ -e tmp-ritmus ]
	then
		file="tmp-ritmus"
	fi
	linenr=$(wc -l < $file)
	line=1
	while [[ $line -le $linenr ]]
	do
        	clear
		crnsor=$(head -n+1 $file)
		echo $crnsor
		echo ""
		tail -n +2 $file > tmp && mv tmp $file

		if ! [[ $crnsor =~ ^[.|s]\ + ]]
		then
			echo \<$line\> sort sajnos nem tudtuk lejatszani
			sleep 2
		else
			for (( itrcrnt=0; itrcrnt < ${#crnsor}; itrcrnt++ ))
			do
    				if [[ ${crnsor:$itrcrnt:1} == "." ]]
    				then
        				echo -n ti-
        				sleep 0.5
    				fi
				if [[ ${crnsor:$itrcrnt:1} == "|" ]]
				then
				        echo -n ta-
        				sleep 1
    				fi
				if [[ ${crnsor:$itrcrnt:1} == "s" ]]
    				then
        				echo -n "*"
    					sleep 1
				fi
			done
		fi
		((line++))
       	done	
        exit 0
fi    

echo usage $0 file/n
exit 1
